import 'package:flutter/material.dart';

const PRIMARYCOLOR = Color.fromARGB(255, 0, 96, 174);
