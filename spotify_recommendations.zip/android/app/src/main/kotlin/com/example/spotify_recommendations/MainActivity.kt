package com.example.spotify_recommendations

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
